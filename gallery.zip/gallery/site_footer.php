<footer>
	<div class="left">
		<div>
			<h3>Site Name</h3>
		</div>
		<div>
			<a href="#"><img src="images/facebook.png" alt="facebook" style="width: 20px; margin: 5px;"></a>
    		<a href="#"><img src="images/instagram.png" alt="facebook" style="width: 20px; margin: 5px;"></a>
		</div>
	</div>
	<div class="right">
		<div>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
		</div>
		<div>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
		</div>
		<div>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
			<p>Links</p>
		</div>
	</div>
</footer>
</body>
</html>